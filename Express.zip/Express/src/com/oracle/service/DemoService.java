package com.oracle.service;


public class DemoService {
	public int add(int a,int b) {
		return a+b;
	}
	public int sub(int a,int b) {
		return a-b;
	}
	
	
}
