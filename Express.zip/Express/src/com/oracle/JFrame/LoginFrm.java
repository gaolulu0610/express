package com.oracle.JFrame;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import com.oracle.entity.User;
import com.oracle.service.UserServiceImpl;
import java.beans.VetoableChangeListener;
import java.beans.PropertyChangeEvent;

public class LoginFrm extends JFrame {

	private JPanel contentPane;
	private JTextField userNameTxt;
	private JPasswordField passwordTxt;
	private UserServiceImpl userServiceImpl = new UserServiceImpl();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrm frame = new LoginFrm();
					frame.setLocationRelativeTo(null);//���ô������
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrm() {
		setResizable(false); //���ò������
		//setLocationRelativeTo(null);//���ô������
		//�ı�ϵͳĬ������
				Font font = new Font("Dialog", Font.PLAIN, 12);
				java.util.Enumeration keys = UIManager.getDefaults().keys();
				while (keys.hasMoreElements()) {
					Object key = keys.nextElement();
					Object value = UIManager.get(key);
					if (value instanceof javax.swing.plaf.FontUIResource) {
						UIManager.put(key, font);
					}
				}
		setTitle("\u5FEB\u9012\u7BA1\u7406\u7CFB\u7EDF");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 927, 428);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel label = new JLabel("\u5FEB\u9012\u7BA1\u7406\u7CFB\u7EDF\u6B22\u8FCE\u60A8\u7684\u767B\u5F55");
		label.setFont(new Font("����", Font.BOLD, 24));
		label.setIcon(new ImageIcon(LoginFrm.class.getResource("/images/email.png")));
		
		JLabel label_1 = new JLabel("\u7528\u6237\u540D\uFF1A");
		label_1.setFont(new Font("����", Font.BOLD, 16));
		label_1.setIcon(new ImageIcon(LoginFrm.class.getResource("/images/userName.png")));
		
		userNameTxt = new JTextField();
		userNameTxt.setColumns(10);
		
		JLabel label_2 = new JLabel("\u5BC6  \u7801\uFF1A");
		label_2.setFont(new Font("����", Font.BOLD, 16));
		label_2.setIcon(new ImageIcon(LoginFrm.class.getResource("/images/about.png")));
		
		passwordTxt = new JPasswordField();
		
		JButton btnNewButton = new JButton("\u767B\u5F55");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				LoginActionPerformed(e);
				
				
			}
		});
		btnNewButton.setIcon(new ImageIcon(LoginFrm.class.getResource("/images/login.png")));
		
		JButton btnNewButton_1 = new JButton("\u91CD\u7F6E");
		btnNewButton_1.setIcon(new ImageIcon(LoginFrm.class.getResource("/images/reset.png")));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				chongZhiActionPerformed(e);
			}
		});
		
		JButton btnNewButton_2 = new JButton("\u6CE8\u518C");
		btnNewButton_2.setIcon(new ImageIcon(LoginFrm.class.getResource("/images/register.png")));
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("\u7BA1\u7406\u5458");
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("\u7528\u6237");
		rdbtnNewRadioButton_1.addVetoableChangeListener(new VetoableChangeListener() {
			public void vetoableChange(PropertyChangeEvent evt) {
			}
		});
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("\u5458\u5DE5");
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(33)
							.addComponent(btnNewButton))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(47)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(label_1)
								.addComponent(label_2))
							.addGap(28)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(237)
									.addComponent(btnNewButton_1))
								.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
									.addComponent(passwordTxt, Alignment.LEADING)
									.addComponent(userNameTxt, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 196, Short.MAX_VALUE)))))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(rdbtnNewRadioButton)
								.addComponent(rdbtnNewRadioButton_1)
								.addComponent(rdbtnNewRadioButton_2))
							.addGap(190))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(btnNewButton_2)
							.addGap(41))))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(237)
					.addComponent(label)
					.addContainerGap(342, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(47)
					.addComponent(label)
					.addGap(5)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(87)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(label_1)
								.addComponent(userNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addGap(34)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(label_2)
								.addComponent(passwordTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(43)
							.addComponent(rdbtnNewRadioButton_1)
							.addGap(30)
							.addComponent(rdbtnNewRadioButton)
							.addGap(34)
							.addComponent(rdbtnNewRadioButton_2)))
					.addPreferredGap(ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnNewButton_1)
						.addComponent(btnNewButton_2))
					.addGap(47))
					
		);
		
		contentPane.setLayout(gl_contentPane);
	}
		/*//��ת��ע�����
		protected void registerActionPerformed(ActionEvent e) {
			this.dispose();//�رյ�ǰ�Ĵ���
			RegisterFrm registerFrm = new RegisterFrm();
			registerFrm.setVisible(true);//��ת��ע��ҳ�沢��ʾ
			registerFrm.setLocationRelativeTo(null);
		}*/

		/*
		 * ����
		 */
		protected void chongZhiActionPerformed(ActionEvent e) {
			userNameTxt.setText("");
			passwordTxt.setText("");
		}

		/*
		 *��¼ :��get���� 90%�����Ӧһ��set  
		 */
		@SuppressWarnings("deprecation")
		protected void LoginActionPerformed(ActionEvent e) {
			String gName = userNameTxt.getText();
	 		String gPassword = new String(passwordTxt.getPassword());//getPassword ���ص���һ��char���͵�����
			System.out.println(gName+"����"+gPassword);
	 		//���û���¼����
			User user = userServiceImpl.login(gName,gPassword );
			if(user!=null) {
				//user = user1;
				JOptionPane.showMessageDialog(null, "�ɹ���¼");
				/*int rank = user.getRank();//���Ȩ��  �ǹ���Ա ���� ��ͨ�Ļ�Ա
				if(rank==1) {//����Ա
					dispose();//��֮ǰ���������
					AdminFrm adminFrm = new AdminFrm();
					adminFrm.setVisible(true);//�����������Ĵ�����ʾ 
				}else if(rank==0) {//���뵽��Ա����ҳ��
					
				}*/
				
			}else{
				JOptionPane.showMessageDialog(null, "�û�����������󣡣���");
			}
		
}
}