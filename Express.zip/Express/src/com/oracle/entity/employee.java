package com.oracle.entity;

public class employee {
	   private Integer YNum;
	   private Integer KNum;
	   private String YName;
       private String YPhoneNum;
	public Integer getYNum() {
		return YNum;
	}
	public void setYNum(Integer yNum) {
		YNum = yNum;
	}
	public Integer getKNum() {
		return KNum;
	}
	public void setKNum(Integer kNum) {
		KNum = kNum;
	}
	public String getYName() {
		return YName;
	}
	public void setYName(String yName) {
		YName = yName;
	}
	public String getYPhoneNum() {
		return YPhoneNum;
	}
	public void setYPhoneNum(String yPhoneNum) {
		YPhoneNum = yPhoneNum;
	}
	@Override
	public String toString() {
		return "employee [YNum=" + YNum + ", KNum=" + KNum + ", YName=" + YName
				+ ", YPhoneNum=" + YPhoneNum + "]";
	}
       
       
}
