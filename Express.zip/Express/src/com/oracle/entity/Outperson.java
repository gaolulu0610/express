package com.oracle.entity;

public class Outperson {
	   private Integer ONum;
	   private Integer YNum;
	   private Integer GNum;
	   private String OName;
	   private String OLocation;
       private String OPhoneNum;
	public Integer getONum() {
		return ONum;
	}
	public void setONum(Integer oNum) {
		ONum = oNum;
	}
	public Integer getYNum() {
		return YNum;
	}
	public void setYNum(Integer yNum) {
		YNum = yNum;
	}
	public Integer getGNum() {
		return GNum;
	}
	public void setGNum(Integer gNum) {
		GNum = gNum;
	}
	public String getOName() {
		return OName;
	}
	public void setOName(String oName) {
		OName = oName;
	}
	public String getOLocation() {
		return OLocation;
	}
	public void setOLocation(String oLocation) {
		OLocation = oLocation;
	}
	public String getOPhoneNum() {
		return OPhoneNum;
	}
	public void setOPhoneNum(String oPhoneNum) {
		OPhoneNum = oPhoneNum;
	}
	@Override
	public String toString() {
		return "Outperson [ONum=" + ONum + ", YNum=" + YNum + ", GNum=" + GNum
				+ ", OName=" + OName + ", OLocation=" + OLocation
				+ ", OPhoneNum=" + OPhoneNum + "]";
	}
       
}
