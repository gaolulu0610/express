package com.oracle.entity;

public class Goods {
        private Integer GNum;
        private Integer INum;
        private String GName;
        private String GKind;
		public Integer getGNum() {
			return GNum;
		}
		public void setGNum(Integer gNum) {
			GNum = gNum;
		}
		public Integer getINum() {
			return INum;
		}
		public void setINum(Integer iNum) {
			INum = iNum;
		}
		public String getGName() {
			return GName;
		}
		public void setGName(String gName) {
			GName = gName;
		}
		public String getGKind() {
			return GKind;
		}
		public void setGKind(String gKind) {
			GKind = gKind;
		}
		@Override
		public String toString() {
			return "Goods [GNum=" + GNum + ", INum=" + INum + ", GName="
					+ GName + ", GKind=" + GKind + "]";
		}
        


}
