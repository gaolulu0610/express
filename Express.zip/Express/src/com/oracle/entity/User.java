package com.oracle.entity;

public class User {
       private Integer GNum; //int Ĭ��ֵΪ0��integer�жϲ�Ϊnull�Ϳ���
       private Integer KNum;
       private String GName;
       private String GPassword;
       private String GPhoneNum;
	public Integer getGNum() {
		return GNum;
	}
	public void setGNum(Integer gNum) {
		GNum = gNum;
	}
	public Integer getKNum() {
		return KNum;
	}
	public void setKNum(Integer kNum) {
		KNum = kNum;
	}
	public String getGName() {
		return GName;
	}
	public void setGName(String gName) {
		GName = gName;
	}
	public String getGPassword() {
		return GPassword;
	}
	public void setGPassword(String gPassword) {
		GPassword = gPassword;
	}
	public String getGPhoneNum() {
		return GPhoneNum;
	}
	public void setGPhoneNum(String gPhoneNum) {
		GPhoneNum = gPhoneNum;
	}
	@Override
	public String toString() {
		return "User [GNum=" + GNum + ", KNum=" + KNum + ", GName=" + GName
				+ ", GPassword=" + GPassword + ", GPhoneNum=" + GPhoneNum + "]";
	}
       
       
      
}
