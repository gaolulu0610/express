package com.oracle.entity;

public class Inperson {
	 private Integer INum;
	 private String IName;
	 private String ILocation;
	 private String IPhoneNum;
	public Integer getINum() {
		return INum;
	}
	public void setINum(Integer iNum) {
		INum = iNum;
	}
	public String getIName() {
		return IName;
	}
	public void setIName(String iName) {
		IName = iName;
	}
	public String getILocation() {
		return ILocation;
	}
	public void setILocation(String iLocation) {
		ILocation = iLocation;
	}
	public String getIPhoneNum() {
		return IPhoneNum;
	}
	public void setIPhoneNum(String iPhoneNum) {
		IPhoneNum = iPhoneNum;
	}
	@Override
	public String toString() {
		return "Inperson [INum=" + INum + ", IName=" + IName + ", ILocation="
				+ ILocation + ", IPhoneNum=" + IPhoneNum + "]";
	}
	 
	
	

}
