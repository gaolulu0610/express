package com.oracle.entity;

import java.util.List;

public class Kdz {
	private Integer KNum;
	private Integer INum;
	private Integer TNum;
	private String KName;
	private String KAddress;
	private String KPhoneNum;
	
	/*private List<Things> Thing;
	
	
	public List<Things> getThing() {
		return Thing;
	}
	public void setThing(List<Things> thing) {
		Thing = thing;
	}*/
	public Integer getKNum() {
		return KNum;
	}
	public void setKNum(Integer kNum) {
		KNum = kNum;
	}
	public Integer getINum() {
		return INum;
	}
	public void setINum(Integer iNum) {
		INum = iNum;
	}
	public Integer getTNum() {
		return TNum;
	}
	public void setTNum(Integer tNum) {
		TNum = tNum;
	}
	public String getKName() {
		return KName;
	}
	public void setKName(String kName) {
		KName = kName;
	}
	public String getKAddress() {
		return KAddress;
	}
	public void setKAddress(String kAddress) {
		KAddress = kAddress;
	}
	public String getKPhoneNum() {
		return KPhoneNum;
	}
	public void setKPhoneNum(String kPhoneNum) {
		KPhoneNum = kPhoneNum;
	}
	@Override
	public String toString() {
		return "Kdz [KNum=" + KNum + ", INum=" + INum + ", TNum=" + TNum
				+ ", KName=" + KName + ", KAddress=" + KAddress
				+ ", KPhoneNum=" + KPhoneNum + "]";
	}
	
	

}
