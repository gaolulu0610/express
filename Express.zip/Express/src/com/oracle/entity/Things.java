package com.oracle.entity;

public class Things {
	     private String TNum;
	     private String TInDate;
	     private String TOutAddress;
	     private String TOutDate;
         private String TInAddress;
		public String getTNum() {
			return TNum;
		}
		public void setTNum(String tNum) {
			TNum = tNum;
		}
		public String getTInDate() {
			return TInDate;
		}
		public void setTInDate(String tInDate) {
			TInDate = tInDate;
		}
		public String getTOutAddress() {
			return TOutAddress;
		}
		public void setTOutAddress(String tOutAddress) {
			TOutAddress = tOutAddress;
		}
		public String getTOutDate() {
			return TOutDate;
		}
		public void setTOutDate(String tOutDate) {
			TOutDate = tOutDate;
		}
		public String getTInAddress() {
			return TInAddress;
		}
		public void setTInAddress(String tInAddress) {
			TInAddress = tInAddress;
		}
		@Override
		public String toString() {
			return "Things [TNum=" + TNum + ", TInDate=" + TInDate
					+ ", TOutAddress=" + TOutAddress + ", TOutDate=" + TOutDate
					+ ", TInAddress=" + TInAddress + "]";
		}
         
}
