package com.oracle.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo {
	public void update() {//mybatis的实�?
		Statement statement = null;
		Connection conn = null;
		String url ="jdbc:mysql://127.0.0.1:3306/demo?characterEncoding=UTF-8";
		String username="root";
		String password="admin";
		String driver ="com.mysql.jdbc.Driver";
		String sql = "insert into user values (default,'cjl','cjl123','2020-07-14',100.0)";
		String sql1 = "update user set username='123',password='456' where id =1";
		String sql2 = "delete from user  where id =1";
		try {
			//加载驱动            
			Class.forName(driver);
			//创建链接
			  conn = DriverManager.getConnection(url, username, password);
			//获得参数对象
			  statement = conn.createStatement();
			//返回�? 就是受sql语句影响的记录行�?  增删�? 
			 int i = statement.executeUpdate(sql2);// 0  1 
			 System.out.println("-------------------->"+sql2);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			 try {
				 if(statement!=null) {
					 statement.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
			 try {
				 if(conn!=null) {
					 conn.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	public User query() {
		Connection conn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		String url ="jdbc:mysql://127.0.0.1:3306/demo?characterEncoding=UTF-8";
		String username="root";
		String password="admin";
		String driver ="com.mysql.jdbc.Driver";
		String sql = "select * from user where id=2";
		User u= new User();
		try {
			//加载驱动            
			Class.forName(driver);
			//创建链接
			  conn = DriverManager.getConnection(url, username, password);
			//获得参数对象
			  statement = conn.createStatement();
			//返回�? 就是受sql语句影响的记录行�?  增删�? 
			  resultSet = statement.executeQuery(sql);
			  //判断下一行有没有数据 返回值是boolean类型 如果有返回true 否则返回flase
			  if(resultSet.next()) {
				   u.setId(resultSet.getInt("id"));
				   u.setUsername(resultSet.getString("username"));
				   u.setPassword(resultSet.getString("password"));
				   u.setCreateTime(resultSet.getDate("createTime"));
				   u.setMoney(resultSet.getFloat("money"));
			  }
			  System.out.println("-------------------->"+sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				 if(resultSet!=null) {
					 resultSet.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
			 try {
				 if(statement!=null) {
					 statement.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
			 try {
				 if(conn!=null) {
					 conn.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return u;
	}
	public String login(String username1,String password1) {
		Connection conn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		String url ="jdbc:mysql://127.0.0.1:3306/demo?characterEncoding=UTF-8";
		String username="root";
		String password="admin";
		String driver ="com.mysql.jdbc.Driver";
		String sql = "select * from user where username='"+username1+"' and password='"+password1+"'";
		System.out.println("-------------------->"+sql);
		User u= new User();
		String rs = "登录失败"; 
		try {
			//加载驱动            
			Class.forName(driver);
			//创建链接
			  conn = DriverManager.getConnection(url, username, password);
			//获得参数对象
			  statement = conn.createStatement();
			//返回�? 就是受sql语句影响的记录行�?  增删�? 
			  resultSet = statement.executeQuery(sql);
			  //判断下一行有没有数据 返回值是boolean类型 如果有返回true 否则返回flase
			  if(resultSet.next()) {
				  if(username.equals(resultSet.getString("username"))&&password.equals(resultSet.getString("password"))) {
					  rs="登录成功";
				  }
				 
				   /*u.setId(resultSet.getInt("id"));
				   u.setUsername(resultSet.getString("username"));
				   u.setPassword(resultSet.getString("password"));
				   u.setCreateTime(resultSet.getDate("createTime"));
				   u.setMoney(resultSet.getFloat("money"));*/
			  }
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				 if(resultSet!=null) {
					 resultSet.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
			 try {
				 if(statement!=null) {
					 statement.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
			 try {
				 if(conn!=null) {
					 conn.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return rs;
	}
	
	public String login1(String id) {
		Connection conn = null;
		ResultSet resultSet = null;
		 PreparedStatement prepareStatement=null;
		String url ="jdbc:mysql://127.0.0.1/demo?characterEncoding=UTF-8";
		String username="root";
		String password="admin";
		String driver ="com.mysql.jdbc.Driver";
		String sql = "select * from user where id= ?";//占位�?
		String rs = "登录失败"; 
		try {
			//加载驱动            
			Class.forName(driver);
			//创建链接
			  conn = DriverManager.getConnection(url, username, password);
			//获得参数对象
			 prepareStatement = conn.prepareStatement(sql);
			 //把参数传到sql语句当中
			 prepareStatement.setInt(1,Integer.parseInt(id));
			//返回�? 就是受sql语句影响的记录行�?  增删�? 
			 System.out.println("-------------------->"+sql);
			 resultSet = prepareStatement.executeQuery();
			  //判断下一行有没有数据 返回值是boolean类型 如果有返回true 否则返回flase
			  if(resultSet.next()) {
					  rs="登录成功";
					  System.out.println(resultSet.getInt("id"));
			  }
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				 if(resultSet!=null) {
					 resultSet.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
			 try {
				 if(prepareStatement!=null) {
					 prepareStatement.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
			 try {
				 if(conn!=null) {
					 conn.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return rs;
	}
	public static void main(String[] args) {
		Demo d = new Demo();
		//sql注入漏洞破坏我原有代码的逻辑
		String string = d.login1("3");
		System.out.println(string);
	}
}
