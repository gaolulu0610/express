package com.oracle.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Express {
	public  void update(){
		Statement statement = null;
		Connection conn = null;
		String url="jdbc:mysql://192.168.0.140:3306/gly?characterEncoding=UTF-8";
		String username="root";
		String password="123456";
		try {  
			//��������
			Class.forName("com.mysql.jdbc.Driver");
			//��������
			 conn = DriverManager.getConnection(url,username,password);
		   //��ȡ����
			 statement =conn.createStatement();
			 @SuppressWarnings("unused")
			String sql = "insert into gly values (default,'19846154679','111111111111','����','123456','19846154679')";
			int i=statement.executeUpdate(sql);
			System.out.println("--------------->"+sql);
			 /*
	        int i = statement.executeUpdate(sql2);// 0  1 
		    String sql = "insert into user values (default,'cjl','cjl123','2020-07-14',100.0)";
			String sql1 = "update user set username='123',password='456' where id =1";
			String sql2 = "delete from user  where id =1";
			//����ֵ ������sql���Ӱ��ļ�¼����
			statement.executeUpdate("insert into");//0  1
*/		}catch (SQLException e){
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally{
			try {
				if(statement!=null) {
					 statement.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
			 try {
				 if(conn!=null) {
					 conn.close();
				 }
			} catch (SQLException e) {
				e.printStackTrace();
				
			}
			
			
		}
		
		
		
		
	}

}
